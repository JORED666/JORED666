import java.util.ArrayList;

public class Suscriptor {
    private String nombre;
    private String apellido;
    private String email;
    private boolean pagoRealizado;
    private ArrayList<String> comentarios;

    public Suscriptor(String nombre,String apellido, String email) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.pagoRealizado = false;
        this.comentarios = new ArrayList<>();
    }


    public void agregarPago() {
        this.pagoRealizado = true;
    }

    public void agregarComentario(String comentario) {
        this.comentarios.add(comentario);
    }

    public String getNombre() {
        return nombre;
    }
    public String getapellido() {
        return apellido;
    }

    public String getEmail() {
        return email;
    }

    public boolean isPagoRealizado() {
        return pagoRealizado;
    }

    public ArrayList<String> getComentarios() {
        return comentarios;
    }

    @Override
    public String toString() {
        return "Suscriptor{" +
                "nombre='" + nombre + '\'' +
                ", apellidos='" + apellido + '\'' +
                ", email='" + email + '\'' +
                ", pagoRealizado=" + pagoRealizado +
                ", comentarios=" + comentarios +
                '}';
    }
}

