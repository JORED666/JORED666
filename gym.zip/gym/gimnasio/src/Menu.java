import java.util.Scanner;

public class Menu {
    public static void mostrar(Base base){
        Scanner scanner = new Scanner(System.in);

        boolean seguir = true;

        while (seguir) {
            System.out.println("\n--- Sistema de Gestión de Cursos ---");
            System.out.println("1. Registrar Suscriptor");
            System.out.println("2. Registrar Instructor");
            System.out.println("3. Registrar Curso");
            System.out.println("4. Eliminar Suscriptor");
            System.out.println("5. Eliminar Instructor");
            System.out.println("6. Eliminar Curso");
            System.out.println("7. Agregar Pago a Suscriptor");
            System.out.println("8. Agregar Comentario a Suscriptor");
            System.out.println("9. Visualizar Suscriptores");
            System.out.println("10. Visualizar Instructores");
            System.out.println("11. Visualizar Cursos");
            System.out.println("12. Salir");

            System.out.print("Selecciona una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1: // Registrar Suscriptor
                    Suscriptor nuevoSuscriptor = Entradadedatos.DatosSuscriptor();
                    //base.agregarSuscriptor(nuevoSuscriptor);
                    base.add(nuevoSuscriptor);
                    break;

                case 2: // Registrar Instructor
                    Instructor nuevoInstructor = Entradadedatos.DatosInstructor();
                    base.agregarInstructor(nuevoInstructor);
                    break;

                case 3: // Registrar Curso
                    Curso nuevoCurso = Entradadedatos.DatosCurso(base);
                    if (nuevoCurso != null) {
                        base.agregarCurso(nuevoCurso);
                    }
                    break;

                case 4: // Eliminar Suscriptor
                    Eliminardatos.eliminarSuscriptor(base);
                    break;

                case 5: // Eliminar Instructor
                    Eliminardatos.eliminarInstructor(base);
                    break;

                case 6: // Eliminar Curso
                    Eliminardatos.eliminarCurso(base);
                    break;

                case 7: // Agregar Pago a Suscriptor
                    Extras.agregarPagoaSuscriptor(base);
                    break;

                case 8: // Agregar Comentario a Suscriptor
                    Extras.agregarComentarioaSuscriptor(base);
                    break;

                case 9: // Visualizar Suscriptores
                    System.out.println("\nLista de Suscriptores:");
                    base.visualizarSuscriptores();
                    break;

                case 10: // visualizar Instructores
                    System.out.println("\nLista de Instructores:");
                    base.visualizarInstructores();
                    break;

                case 11: // visualizar Cursos
                    System.out.println("\nLista de Cursos:");
                    base.visualizarCursos();
                    break;

                case 12: // Salir
                    seguir = false;
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción no válida. Intenta nuevamente.");
                    break;
            }
        }

    }
}
