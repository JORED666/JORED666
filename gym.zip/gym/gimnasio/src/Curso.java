public class Curso {
    private String nombre;
    private int duracionHoras;
    private Instructor instructor;

    public Curso(String nombre, int duracionHoras, Instructor instructor) {
        this.nombre = nombre;
        this.duracionHoras = duracionHoras;
        this.instructor = instructor;
    }


    public String getNombre() {
        return nombre;
    }

    public int getDuracionHoras() {
        return duracionHoras;
    }

    public Instructor getInstructor() {
        return instructor;
    }

    @Override
    public String toString() {
        return "Curso{" +
                "nombre='" + nombre + '\'' +
                ", duracionHoras=" + duracionHoras +
                ", instructor=" + (instructor != null ? instructor.getNombre() : "No asignado") +
                '}';
    }
}
