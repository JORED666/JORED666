import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Base base = new Base();
        Menu.mostrar(base);
    conexion con = new conexion();
    }
}
