import java.util.ArrayList;
import java.sql.*;

public class Base {
    private ArrayList<Suscriptor> suscriptores;
    private ArrayList<Instructor> instructores;
    private ArrayList<Curso> cursos;

    public Base() {
        this.suscriptores = new ArrayList<>();
        this.instructores = new ArrayList<>();
        this.cursos = new ArrayList<>();
    }
    private static final String URL = "jdbc:mariadb://localhost:3306/gimnasio";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public void agregarSuscriptor(Suscriptor suscriptor) {
        suscriptores.add(suscriptor);
    }
    public boolean add(Suscriptor sus) {
    String sql = "INSERT INTO suscriptores(nombre, apellido,email,pagoRealizado) VALUES (?, ?, ?, ?)";

    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
    PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
    pstmt.setString(1, sus.getNombre());
    pstmt.setString(2, sus.getapellido());
    pstmt.setString(3, sus.getEmail());
    pstmt.setBoolean(4, sus.isPagoRealizado());



    int affectedRows = pstmt.executeUpdate();

    if (affectedRows > 0) {
    try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
    if (generatedKeys.next()) {
    suscriptores.add(sus);
    }
    }
    return true;
    }
    return false;
    } catch (SQLException e) {
    System.err.println("Error al insertar usuario: " + e.getMessage());
    return false;
    }
    }



    public void agregarInstructor(Instructor instructor) {
        instructores.add(instructor);
    }

    public void agregarCurso(Curso curso) {
        cursos.add(curso);
    }


    public void eliminarSuscriptor(Suscriptor suscriptor) {
        suscriptores.remove(suscriptor);
    }

    public void eliminarInstructor(Instructor instructor) {
        instructores.remove(instructor);
    }

    public void eliminarCurso(Curso curso) {
        cursos.remove(curso);
    }


    public void visualizarSuscriptores() {
        for (Suscriptor s : suscriptores) {
            System.out.println(s);
        }
    }

    public void visualizarInstructores() {
        for (Instructor i : instructores) {
            System.out.println(i);
        }
    }

    public void visualizarCursos() {
        for (Curso c : cursos) {
            System.out.println(c);
        }
    }


    public ArrayList<Suscriptor> getSuscriptores() {
        return suscriptores;
    }

    public ArrayList<Instructor> getInstructores() {
        return instructores;
    }

    public ArrayList<Curso> getCursos() {
        return cursos;
    }
}
