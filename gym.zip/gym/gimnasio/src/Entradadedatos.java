import java.util.Scanner;

public class Entradadedatos {
    private static Scanner sc = new Scanner(System.in);
    private static Base base;
    public static void config(Base b){
        base = b;
    }

    public static Suscriptor DatosSuscriptor() {
        System.out.print("Ingresa nombre del suscriptor: ");
        String nombreSuscriptor = sc.nextLine();
        System.out.print("Ingresa apellido del suscriptor: ");
        String apellidoSuscriptor = sc.nextLine();
        System.out.print("Ingresa el email del suscriptor: ");
        String emailSuscriptor = sc.nextLine();
        System.out.println("Suscriptor registrado con éxito.");
        return new Suscriptor(nombreSuscriptor, apellidoSuscriptor, emailSuscriptor);

    }
    public static Instructor DatosInstructor() {
        System.out.print("Ingresa  nombre del instructor: ");
        String nombreInstructor = sc.nextLine();
        System.out.print("Ingresa apellido del instructor: ");
        String apellidoInstructor = sc.nextLine();
        System.out.print("Ingresa la especialidad del instructor: ");
        String especialidadInstructor = sc.nextLine();
        System.out.println("Instructor registrado con éxito.");
        return new Instructor(nombreInstructor, apellidoInstructor, especialidadInstructor);
    }
    public static Curso DatosCurso(Base base) {
        System.out.print("Ingresa el nombre del curso: ");
        String nombreCurso = sc.nextLine();
        System.out.print("Ingresa la duración del curso (en horas): ");
        int duracionCurso = sc.nextInt();
        sc.nextLine();
        System.out.print("Ingresa el nombre del instructor para el curso: ");
        String nombreInstructorCurso = sc.nextLine();

        // Buscar el instructor por nombre
        Instructor instructorCurso = null;
        for (Instructor i : base.getInstructores()) {
            if (i.getNombre().equals(nombreInstructorCurso)) {
                instructorCurso = i;
                break;
            }
        }

        if (instructorCurso != null) {
            Curso curso = new Curso(nombreCurso, duracionCurso, instructorCurso);
            base.agregarCurso(curso);
            System.out.println("Curso registrado con éxito.");
        } else {
            System.out.println("Instructor no encontrado.No se registró el curso.");
        }
        return null;
    }


}
