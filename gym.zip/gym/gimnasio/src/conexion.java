import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexion {
    private static final String Url = "jdbc:mysql://localhost:3306/gimnasio";
    private static final String User = "root";
    private static final String Password = "";

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(Url, User, Password);
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
            return null;
        }
    }
}





