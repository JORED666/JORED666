import java.util.Scanner;

public class Eliminardatos {
    private static Scanner sc = new Scanner(System.in);
    private static Base base;

    public static void config(Base b) {
        base = b;
    }

    public static void eliminarSuscriptor(Base base) {
        System.out.print("Ingresa el nombre del suscriptor a eliminar: ");
        String nombreEliminarSuscriptor = sc.nextLine();
        Suscriptor suscriptorEliminar = null;
        for (Suscriptor s : base.getSuscriptores()) {
            if (s.getNombre().equals(nombreEliminarSuscriptor)) {
                suscriptorEliminar = s;
                break;
            }
        }
        if (suscriptorEliminar != null) {
            base.eliminarSuscriptor(suscriptorEliminar);
            System.out.println("Suscriptor eliminado con éxito.");
        } else {
            System.out.println("Suscriptor no encontrado.");
        }
    }
    public static void eliminarInstructor(Base base) {
        System.out.print("Ingresa el nombre del instructor a eliminar: ");
        String nombreEliminarInstructor = sc.nextLine();
        Instructor instructorEliminar = null;
        for (Instructor i : base.getInstructores()) {
            if (i.getNombre().equals(nombreEliminarInstructor)) {
                instructorEliminar = i;
                break;
            }
        }
        if (instructorEliminar != null) {
            base.eliminarInstructor(instructorEliminar);
            System.out.println("Instructor eliminado con éxito.");
        } else {
            System.out.println("Instructor no encontrado.");
        }
    }
    public static void eliminarCurso(Base base) {
        System.out.print("Ingresa el nombre del curso a eliminar: ");
        String nombreEliminarCurso = sc.nextLine();
        Curso cursoEliminar = null;
        for (Curso c : base.getCursos()) {
            if (c.getNombre().equals(nombreEliminarCurso)) {
                cursoEliminar = c;
                break;
            }
        }
        if (cursoEliminar != null) {
            base.eliminarCurso(cursoEliminar);
            System.out.println("Curso eliminado con éxito.");
        } else {
            System.out.println("Curso no encontrado.");
        }
    }

}


