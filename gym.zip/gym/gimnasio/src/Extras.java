import java.util.Scanner;

public class Extras {
    private static Scanner sc = new Scanner(System.in);

        public static void agregarComentarioaSuscriptor (Base base){
            System.out.print("Ingresa el nombre del suscriptor al que le agregarás el comentario: ");
            String nombreSuscriptorComentario = sc.nextLine();
            Suscriptor suscriptorComentario = null;
            for (Suscriptor s : base.getSuscriptores()) {
                if (s.getNombre().equals(nombreSuscriptorComentario)) {
                    suscriptorComentario = s;
                    break;
                }
            }
            if (suscriptorComentario != null) {
                System.out.print("Ingresa el comentario: ");
                String comentario = sc.nextLine();
                suscriptorComentario.agregarComentario(comentario);
                System.out.println("Comentario agregado con éxito.");
            } else {
                System.out.println("Suscriptor no encontrado.");
            }
        }

    public static void agregarPagoaSuscriptor (Base base){
        System.out.print("Ingresa el nombre del suscriptor al que le agregarás el pago: ");
        String nombreSuscriptorPago = sc.nextLine();
        Suscriptor suscriptorPago = null;
        for (Suscriptor s : base.getSuscriptores()) {
            if (s.getNombre().equals(nombreSuscriptorPago)) {
                suscriptorPago = s;
                break;
            }
        }
        if (suscriptorPago != null) {
            suscriptorPago.agregarPago();
            System.out.println("Pago agregado con éxito.");
        } else {
            System.out.println("Suscriptor no encontrado.");
        }
    }
}

